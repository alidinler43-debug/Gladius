#!/bin/bash
# Gladius APK build: called by the GitHub "APK oluştur" workflow
set -e
ROOT="$PWD"; P="$ROOT/proje"
mkdir -p ~/.android && cp "$P/debug.keystore" ~/.android/debug.keystore
rm -rf app && mkdir -p app/www && cp "$P/index.html" app/www/index.html
cd app
npm init -y > /dev/null
npm install @capacitor/core@6 @capacitor/cli@6 @capacitor/android@6 @capacitor/haptics@6
npx cap init Gladius com.alidinler.gladius --web-dir www
npx cap add android
sed -i 's/<activity/<activity android:screenOrientation="sensorLandscape"/' android/app/src/main/AndroidManifest.xml
cp "$P/MainActivity.java" android/app/src/main/java/com/alidinler/gladius/MainActivity.java
npx cap sync android
cd android && chmod +x gradlew && ./gradlew assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk "$ROOT/Gladius.apk"
